// Entry point za aplikacijo
console.log('Marko Wellness app');