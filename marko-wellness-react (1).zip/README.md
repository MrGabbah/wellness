# Marko Wellness (React različica)

Ta aplikacija vključuje vse komponente za sledenje aktivnosti, AI napoved in PWA podporo.